document.addEventListener("DOMContentLoaded", () => {
  const fileNames = [
    "tetelek/1._Ismertesse_a_gazdasági_(üzleti)_jog_fogalmát,_mutassa_be_a_gazdasági_jog_(üzleti_jog)_alkotmányi_kereteit.txt",
    "tetelek/2._Ismertesse_az_alkotmány_és_az_alkotmányosság_fogalmát,_mutassa_be_az_alkotmányok_típusait,_jellemzőit!.txt",
    "tetelek/3._Ismertesse_a_jogállamiság,_a_demokrácia,_a_szuverenitás_és_a_piacgazdaság_fogalmát!.txt",
    "tetelek/4._Ismertesse_és_csoportosítsa_a_jogforrásokat,_jogszabályokat_és_a_jogalkotókat!!.txt",
    "tetelek/5._Ismertesse_a_jogrendszer_rétegződésének_megjelenési_formáit_és_határozza_meg_a_dologi_jog_és_a_kötelmi_jog_elhelyezkedését_a_jogrendszeren_belül!.txt",
    "tetelek/6._Határozza_meg_a_dologi_jog_fogalmát,_ismertesse_alapelveit_és_felosztási_módjait!.txt",
    "tetelek/7._Mutassa_be_a_tulajdonjog_alanyát,_tárgyát,_a_tulajdonhoz_kapcsolódó_kötelezettségeket,_korlátokat_és_a_tulajdonjog_megszerzésének_és_megszűnésének_módjait!.txt",
    "tetelek/8._Mutassa_be_a_korlátolt_dologi_jogokat!.txt",
    "tetelek/9._Mutassa_be_az_ingatlan-nyilvántartás_intézményét!.txt",
    "tetelek/10._Ismertesse_a_kötelem_fogalmát_és_általános_szabályait,_a_szerződések_fontosabb_szabályait,_típusait,_fajtáit,_illetve_az_egyéb_kötelem_keletkeztető_tényeket!.txt",
    "tetelek/11._Hasonlítsa_össze_a_közkereseti_társaság,_a_betéti_társaság,_a_korlátolt_felelősségű_társaság_és_a_részvénytársaságok_szabályozását_a_Ptk._alapján!.txt",
    "tetelek/12._Mutassa_be_a_szövetkezet_és_az_egyesülés_szabályozását_a_Ptk._alapján!.txt",
    "tetelek/13._Ismertesse_az_egyéni_vállalkozás_és_az_egyéni_cég_fogalmát,_szabályozásának_fontosabb_elemeit!.txt",
    "tetelek/16._Mutassa_be_az_általános_reklámtilalmakat_és_reklámkorlátozásokat,_illetve_az_egyes_áruk_reklámozására_és_az_azokkal_összefüggésben_történő_szponzorálásra_vonatkozó_tilalmakat_és_korlátozásokat!.txt",
    "tetelek/17._Mit_értünk_a_sajtószabadság_alatt.txt",
    "tetelek/18._Melyek_a_2010._évi_CLXXXV._törvény_a_médiaszolgáltatásokról_és_a_tömegkommunikációról_alapelvei_és_a_médiaszolgáltatások_tartalmára_vonatkozó_fontosabb_előírások!_.txt",
  ];

  const lista = document.getElementById("lista");
  fileNames.forEach((fileName) => {
    const button = document.createElement("button");
    const hr = document.createElement("hr");

    // Csak a fájlnév lényeges részének kinyerése
    const cleanedFileName = fileName
      .replace("tetelek/", "") // "tetelek/" eltávolítása
      .replace(/_/g, " ") // Alsó vonalak helyettesítése szóközökkel
      .replace(".txt", ""); // ".txt" eltávolítása

    button.textContent = cleanedFileName;

    button.addEventListener("click", () => {
      // A megfelelő fájl tartalmának betöltése és megjelenítése
      fetch(fileName)
        .then((response) => {
          if (!response.ok) {
            throw new Error(`Nem sikerült betölteni a fájlt: ${fileName}`);
          }
          return response.text();
        })
        .then((content) => {
          // Mindkét helyre beillesztés
          document.getElementById("textOutput_desktop").innerHTML = content;
          document.getElementById("textOutput_fullscreen").innerHTML = content;
        })
        .catch((error) => {
          document.getElementById(
            "textOutput_desktop"
          ).innerHTML = `<span style="color: red;">Hiba: ${error.message}</span>`;
          document.getElementById(
            "textOutput_fullscreen"
          ).innerHTML = `<span style="color: red;">Hiba: ${error.message}</span>`;
        });
    });

    lista.appendChild(button);
    lista.appendChild(hr);
  });
});
